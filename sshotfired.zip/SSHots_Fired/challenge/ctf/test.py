from ecdsa import SigningKey, NIST521p, VerifyingKey, util, ellipticcurve
from ecdsa import util
import hashlib, os
from random import randint

G = NIST521p.generator
ORDER = G.order()
gx,gy = G.x(), G.y()
CURVE = NIST521p

def gen_ecdsa_lib_keys():
    private_key = SigningKey.generate(curve=NIST521p)
    public_key = private_key.verifying_key
    d = private_key.privkey.secret_multiplier  
    x, y = public_key.pubkey.point.x(), public_key.pubkey.point.y()  
    print(f"Private Key (d): {d}")
    print(f"Public Key (X, Y): ({x}, {y})")
    return d, (x, y)

def ecdsa_lib_sign(d, m, k_i):
    
    private_key = SigningKey.from_secret_exponent(d, curve=NIST521p)
    # sign the message m deterministically
    msg = digest(m, type='digest')
    signature = private_key.sign_digest(msg, k=k_i)
    r,s = util.sigdecode_string(signature, CURVE.order)
    return (r,s)

    

def verify_ecdsa_lib_sig(pub_coords, message, r, s):
    """Validates the ECDSA signature using the provided public key coordinates."""
    curve = NIST521p
    point = ellipticcurve.Point(curve.curve, pub_coords[0], pub_coords[1])
    public_key = VerifyingKey.from_public_point(point, curve)

    if isinstance(message, str):
        message = message.encode()
    try:
        signature = util.sigencode_string(r, s, curve.order)
        is_valid = public_key.verify(signature, message, hashlib.sha256)
        print("Verification Result:", is_valid)
        return is_valid
    except Exception as e:
        print("Verification failed:", e)
        return False

def digest(msg, type='integer'):
    if isinstance(msg, str):
        msg = msg.encode()
    if type == 'integer':
        return int.from_bytes(hashlib.sha512(msg).digest(), byteorder='big')
    elif type == 'digest':
        return hashlib.sha256(msg).digest()
    
def get_k():
    return int.from_bytes(hashlib.sha512(os.urandom(512//8)).digest(), byteorder='big')
from utils import *
from sage.all import *
def main():
    priv,pub = gen_ecdsa_lib_keys()
    
    h = []
    r_i = []
    s_i = []
    k_i = []
    for i in range(10):
        attempt = 0
        print(f"Attempt: {i}")
        for i in range(0, 65):
            k = get_k()
            message = b'message'
            h_i = digest(message, type='integer')
            h.append(h_i)
            k_i.append(PartialInteger.from_bits_be("000000000"+("?"*512)))
            r, s = ecdsa_lib_sign(priv, message, k)
            r_i.append(r)
            s_i.append(s)
        for d_, _ in dsa_known_msb(ORDER, h, r_i, s_i, k_i):
            if check_public_key(int(d_), curve, pub[0], pub[1]):
                print(f"Private key found: {d_}")
                break

if __name__ == "__main__":
    main()