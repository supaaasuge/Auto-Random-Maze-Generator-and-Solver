#/bin/bash
rm -f /home/sage/docker-entrypoint.sh
/usr/sbin/sshd -D
/usr/sbin/xinetd -dontfork